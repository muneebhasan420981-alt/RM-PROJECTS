/* =================================================
                    MOBILE MENU
================================================= */

const menuBtn =
    document.getElementById("menuBtn");

const navbar =
    document.getElementById("navbar");


menuBtn.addEventListener("click", () => {

    navbar.classList.toggle("active");

    const icon =
        menuBtn.querySelector("i");

    icon.classList.toggle("fa-bars");

    icon.classList.toggle("fa-xmark");

});


document.querySelectorAll("#navbar a")
.forEach(link => {

    link.addEventListener("click", () => {

        navbar.classList.remove("active");

        const icon =
            menuBtn.querySelector("i");

        icon.classList.add("fa-bars");

        icon.classList.remove("fa-xmark");

    });

});



/* =================================================
                    DARK MODE
================================================= */

const themeBtn =
    document.getElementById("themeBtn");


themeBtn.addEventListener("click", () => {

    document.body.classList.toggle("dark");


    const icon =
        themeBtn.querySelector("i");


    icon.classList.toggle("fa-moon");

    icon.classList.toggle("fa-sun");

});



/* =================================================
                 DEMO MODAL
================================================= */

const demoBtn =
    document.getElementById("demoBtn");

const demoModal =
    document.getElementById("demoModal");

const closeModal =
    document.getElementById("closeModal");

const demoCloseBtn =
    document.getElementById("demoCloseBtn");


demoBtn.addEventListener("click", () => {

    demoModal.classList.add("active");

});


closeModal.addEventListener("click", () => {

    demoModal.classList.remove("active");

});


demoCloseBtn.addEventListener("click", () => {

    demoModal.classList.remove("active");

});


demoModal.addEventListener("click", event => {

    if (event.target === demoModal) {

        demoModal.classList.remove("active");

    }

});



/* =================================================
                ADD TASK
================================================= */

const addTaskBtn =
    document.getElementById("addTaskBtn");


addTaskBtn.addEventListener("click", () => {

    const task =
        prompt("Enter your new task:");


    if (task === null) {

        return;

    }


    if (task.trim() === "") {

        alert("Please enter a task.");

        return;

    }


    const taskPanel =
        document.querySelector(".task-panel");


    const newTask =
        document.createElement("label");


    newTask.className = "task-row";


    newTask.innerHTML = `

        <input type="checkbox">

        <span>
            ${task}
        </span>

        <small>
            New
        </small>

    `;


    taskPanel.appendChild(newTask);


    newTask
        .querySelector("input")
        .addEventListener("change", function() {

            newTask
                .querySelector("span")
                .classList.toggle(
                    "completed",
                    this.checked
                );

        });

});



/* =================================================
                 TASK CHECKBOXES
================================================= */

document.querySelectorAll(".task-row input")
.forEach(checkBox => {

    checkBox.addEventListener("change", () => {

        const text =
            checkBox.parentElement
                .querySelector("span");


        text.classList.toggle(
            "completed",
            checkBox.checked
        );

    });

});



/* =================================================
                   FOCUS MODE
================================================= */

const focusBtn =
    document.getElementById("focusBtn");


let focusActive = false;


focusBtn.addEventListener("click", () => {

    focusActive = !focusActive;


    if (focusActive) {

        focusBtn.innerHTML = `

            <i class="fa-solid fa-stop"></i>

            Stop Focus

        `;


        alert(
            "Focus Mode started! Stay focused for the next 25 minutes."
        );

    }

    else {

        focusBtn.innerHTML = `

            <i class="fa-solid fa-play"></i>

            Start Focus

        `;

    }

});



/* =================================================
                  BILLING TOGGLE
================================================= */

const billingToggle =
    document.getElementById(
        "billingToggle"
    );


const priceValues =
    document.querySelectorAll(
        ".price-value"
    );


let yearly =
    false;


billingToggle.addEventListener("click", () => {

    yearly = !yearly;


    billingToggle.classList.toggle(
        "yearly"
    );


    priceValues.forEach(price => {

        if (yearly) {

            price.textContent =
                price.dataset.yearly;

        }

        else {

            price.textContent =
                price.dataset.monthly;

        }

    });

});



/* =================================================
              TESTIMONIAL SLIDER
================================================= */

const testimonialItems =
    document.querySelectorAll(
        ".testimonial-item"
    );


let testimonialIndex = 0;


function showTestimonial(index) {

    testimonialItems.forEach(item => {

        item.classList.remove("active");

    });


    testimonialItems[index]
        .classList.add("active");

}


document
    .getElementById("testimonialNext")
    .addEventListener("click", () => {

        testimonialIndex++;


        if (
            testimonialIndex >=
            testimonialItems.length
        ) {

            testimonialIndex = 0;

        }


        showTestimonial(
            testimonialIndex
        );

    });


document
    .getElementById("testimonialPrev")
    .addEventListener("click", () => {

        testimonialIndex--;


        if (testimonialIndex < 0) {

            testimonialIndex =
                testimonialItems.length - 1;

        }


        showTestimonial(
            testimonialIndex
        );

    });



/* Automatic testimonial */

setInterval(() => {

    testimonialIndex++;


    if (
        testimonialIndex >=
        testimonialItems.length
    ) {

        testimonialIndex = 0;

    }


    showTestimonial(
        testimonialIndex
    );

}, 6000);



/* =================================================
                  ANIMATED STATS
================================================= */

const stats =
    document.querySelectorAll(
        ".stats strong"
    );


let statsAnimated = false;


function animateStats() {

    if (statsAnimated) return;


    const section =
        document.querySelector(".stats");


    const position =
        section
            .getBoundingClientRect()
            .top;


    if (
        position <
        window.innerHeight - 100
    ) {

        statsAnimated = true;


        stats.forEach(stat => {

            const target =
                Number(
                    stat.dataset.target
                );


            let count = 0;


            const increment =
                target / 60;


            function update() {

                count += increment;


                if (count < target) {

                    stat.textContent =
                        Math.floor(count);

                    requestAnimationFrame(
                        update
                    );

                }

                else {

                    stat.textContent =
                        target;

                }

            }


            update();

        });

    }

}


window.addEventListener(
    "scroll",
    animateStats
);


animateStats();



/* =================================================
                  CONTACT FORM
================================================= */

const contactForm =
    document.getElementById(
        "contactForm"
    );


contactForm.addEventListener(
    "submit",
    event => {

        event.preventDefault();


        const name =
            document.getElementById(
                "name"
            ).value;


        alert(
            `Welcome to Productiva, ${name}! Your account setup request has been received.`
        );


        contactForm.reset();

    }
);



/* =================================================
                HEADER SCROLL EFFECT
================================================= */

window.addEventListener(
    "scroll",
    () => {

        const header =
            document.querySelector("header");


        if (window.scrollY > 40) {

            header.style.boxShadow =
                "0 5px 25px rgba(0,0,0,.08)";

        }

        else {

            header.style.boxShadow =
                "none";

        }

    }
);



/* =================================================
             SCROLL REVEAL EFFECT
================================================= */

const revealElements =
    document.querySelectorAll(
        ".feature-card, .step, .price-card, .contact"
    );


const revealObserver =
    new IntersectionObserver(
        entries => {

            entries.forEach(entry => {

                if (entry.isIntersecting) {

                    entry.target.style.opacity =
                        "1";

                    entry.target.style.transform =
                        "translateY(0)";

                }

            });

        },
        {
            threshold: .15
        }
    );


revealElements.forEach(element => {

    element.style.opacity = "0";

    element.style.transform =
        "translateY(30px)";

    element.style.transition =
        "opacity .6s ease, transform .6s ease";

    revealObserver.observe(element);

});