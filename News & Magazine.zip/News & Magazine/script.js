/* =================================================
                  MOBILE NAVIGATION
================================================= */

const menuBtn =
    document.getElementById("menuBtn");

const navbar =
    document.getElementById("navbar");


menuBtn.addEventListener("click", () => {

    navbar.classList.toggle("active");

    const icon =
        menuBtn.querySelector("i");

    icon.classList.toggle("fa-bars");

    icon.classList.toggle("fa-xmark");

});


document
    .querySelectorAll("#navbar a")
    .forEach(link => {

        link.addEventListener("click", () => {

            navbar.classList.remove("active");

        });

    });



/* =================================================
                    THEME TOGGLE
================================================= */

const themeBtn =
    document.getElementById("themeBtn");


themeBtn.addEventListener("click", () => {

    document.body.classList.toggle("dark");


    const icon =
        themeBtn.querySelector("i");


    icon.classList.toggle("fa-moon");

    icon.classList.toggle("fa-sun");

});



/* =================================================
                     SEARCH
================================================= */

const searchBtn =
    document.getElementById("searchBtn");

const searchBox =
    document.getElementById("searchBox");

const closeSearch =
    document.getElementById("closeSearch");

const searchInput =
    document.getElementById("searchInput");


searchBtn.addEventListener("click", () => {

    searchBox.classList.add("active");

    searchInput.focus();

});


closeSearch.addEventListener("click", () => {

    searchBox.classList.remove("active");

    searchInput.value = "";

});


/* Search articles */

searchInput.addEventListener("input", () => {

    const search =
        searchInput.value.toLowerCase();


    document
        .querySelectorAll(".news-card")
        .forEach(card => {

            const title =
                card.dataset.title
                    .toLowerCase();


            if (
                title.includes(search)
            ) {

                card.style.display =
                    "block";

            }

            else {

                card.style.display =
                    "none";

            }

        });

});



/* =================================================
                  BREAKING TICKER
================================================= */

const tickerText =
    document.getElementById(
        "tickerText"
    );


const breakingNews = [

    "Global markets react to latest economic developments",

    "Major technology announcement expected today",

    "Sports championship enters its final stage",

    "World leaders gather for major international summit",

    "New innovations could transform the future of cities"

];


let tickerIndex = 0;


document
    .getElementById("tickerNext")
    .addEventListener("click", () => {

        tickerIndex++;


        if (
            tickerIndex >=
            breakingNews.length
        ) {

            tickerIndex = 0;

        }


        tickerText.textContent =
            breakingNews[tickerIndex];

    });



/* =================================================
                  CATEGORY FILTER
================================================= */

const filters =
    document.querySelectorAll(
        ".filter"
    );


const newsCards =
    document.querySelectorAll(
        ".news-card"
    );


filters.forEach(filter => {

    filter.addEventListener(
        "click",
        () => {

            filters.forEach(button => {

                button.classList.remove(
                    "active"
                );

            });


            filter.classList.add(
                "active"
            );


            const category =
                filter.dataset.category;


            newsCards.forEach(card => {

                if (
                    category === "all" ||
                    card.dataset.category ===
                    category
                ) {

                    card.classList.remove(
                        "hidden"
                    );

                }

                else {

                    card.classList.add(
                        "hidden"
                    );

                }

            });

        }
    );

});



/* =================================================
                  ARTICLE MODAL
================================================= */

const articleModal =
    document.getElementById(
        "articleModal"
    );


const modalTitle =
    document.getElementById(
        "modalTitle"
    );


const modalCategory =
    document.getElementById(
        "modalCategory"
    );


const closeArticle =
    document.getElementById(
        "closeArticle"
    );


document
    .querySelectorAll(".article-click")
    .forEach(article => {

        article.addEventListener(
            "click",
            () => {

                const title =
                    article.dataset.title ||
                    "Latest News";


                const category =
                    article.dataset.category ||
                    "NEWS";


                modalTitle.textContent =
                    title;


                modalCategory.textContent =
                    category.toUpperCase();


                articleModal.classList.add(
                    "active"
                );

            }
        );

    });


closeArticle.addEventListener(
    "click",
    () => {

        articleModal.classList.remove(
            "active"
        );

    }
);


articleModal.addEventListener(
    "click",
    event => {

        if (
            event.target ===
            articleModal
        ) {

            articleModal.classList.remove(
                "active"
            );

        }

    }
);



/* =================================================
                  NEWSLETTER
================================================= */

const newsletterForm =
    document.getElementById(
        "newsletterForm"
    );


newsletterForm.addEventListener(
    "submit",
    event => {

        event.preventDefault();


        const email =
            document.getElementById(
                "email"
            ).value;


        if (email) {

            alert(
                "Thanks for subscribing to The Daily!"
            );


            newsletterForm.reset();

        }

    }
);



/* =================================================
                  CONTINUE READING
================================================= */

document
    .getElementById("readBtn")
    .addEventListener("click", () => {

        alert(
            "The full article page would open here."
        );

    });



/* =================================================
                  SCROLL ANIMATION
================================================= */

const animatedElements =
    document.querySelectorAll(
        ".news-card, .trend-card, .hero-main, .side-story"
    );


const observer =
    new IntersectionObserver(
        entries => {

            entries.forEach(entry => {

                if (
                    entry.isIntersecting
                ) {

                    entry.target.style.opacity =
                        "1";

                    entry.target.style.transform =
                        "translateY(0)";

                }

            });

        },
        {
            threshold: .1
        }
    );


animatedElements.forEach(element => {

    element.style.opacity = "0";

    element.style.transform =
        "translateY(25px)";

    element.style.transition =
        "opacity .6s ease, transform .6s ease";

    observer.observe(element);

});



/* =================================================
                  KEYBOARD ESCAPE
================================================= */

document.addEventListener(
    "keydown",
    event => {

        if (event.key === "Escape") {

            articleModal.classList.remove(
                "active"
            );

            searchBox.classList.remove(
                "active"
            );

        }

    }
);