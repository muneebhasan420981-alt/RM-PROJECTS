/* =================================================
                 MOBILE MENU
================================================= */

const menuBtn =
    document.getElementById("menuBtn");

const navbar =
    document.getElementById("navbar");


menuBtn.addEventListener("click", () => {

    navbar.classList.toggle("active");

    const icon =
        menuBtn.querySelector("i");

    icon.classList.toggle("fa-bars");

    icon.classList.toggle("fa-xmark");

});


document.querySelectorAll("#navbar a")
.forEach(link => {

    link.addEventListener("click", () => {

        navbar.classList.remove("active");

        const icon =
            menuBtn.querySelector("i");

        icon.classList.add("fa-bars");

        icon.classList.remove("fa-xmark");

    });

});



/* =================================================
                 DARK MODE
================================================= */

const themeBtn =
    document.getElementById("themeBtn");


themeBtn.addEventListener("click", () => {

    document.body.classList.toggle("dark");

    const icon =
        themeBtn.querySelector("i");

    icon.classList.toggle("fa-moon");

    icon.classList.toggle("fa-sun");

});



/* =================================================
                 HERO SLIDER
================================================= */

const heroSlides =
    document.querySelectorAll(".hero-slide");

const dots =
    document.querySelectorAll(".dot");

let currentSlide = 0;


function showHeroSlide(index) {

    heroSlides.forEach(slide => {

        slide.classList.remove("active");

    });


    dots.forEach(dot => {

        dot.classList.remove("active");

    });


    heroSlides[index]
        .classList.add("active");

    dots[index]
        .classList.add("active");

}


document.getElementById("nextSlide")
.addEventListener("click", () => {

    currentSlide++;

    if (
        currentSlide >=
        heroSlides.length
    ) {

        currentSlide = 0;

    }

    showHeroSlide(currentSlide);

});


document.getElementById("prevSlide")
.addEventListener("click", () => {

    currentSlide--;

    if (currentSlide < 0) {

        currentSlide =
            heroSlides.length - 1;

    }

    showHeroSlide(currentSlide);

});


dots.forEach((dot, index) => {

    dot.addEventListener("click", () => {

        currentSlide = index;

        showHeroSlide(currentSlide);

    });

});



/* =================================================
              DESTINATION FILTER
================================================= */

const filterButtons =
    document.querySelectorAll(
        ".destination-filter"
    );


const destinationCards =
    document.querySelectorAll(
        ".destination-card"
    );


filterButtons.forEach(button => {

    button.addEventListener("click", () => {


        filterButtons.forEach(btn => {

            btn.classList.remove("active");

        });


        button.classList.add("active");


        const selected =
            button.dataset.filter;


        destinationCards.forEach(card => {

            const category =
                card.dataset.category;


            if (
                selected === "all" ||
                selected === category
            ) {

                card.style.display = "block";

                setTimeout(() => {

                    card.style.opacity = "1";

                    card.style.transform =
                        "scale(1)";

                }, 50);

            }

            else {

                card.style.opacity = "0";

                card.style.transform =
                    "scale(.85)";

                setTimeout(() => {

                    card.style.display = "none";

                }, 300);

            }

        });

    });

});



/* =================================================
                FAVORITE BUTTONS
================================================= */

document.querySelectorAll(".favorite")
.forEach(button => {

    button.addEventListener("click", () => {

        button.classList.toggle("active");

        const icon =
            button.querySelector("i");

        icon.classList.toggle(
            "fa-regular"
        );

        icon.classList.toggle(
            "fa-solid"
        );

    });

});



/* =================================================
                  SEARCH
================================================= */

const searchInput =
    document.getElementById(
        "destinationSearch"
    );


const searchBtn =
    document.getElementById(
        "searchBtn"
    );


searchBtn.addEventListener("click", () => {

    const searchValue =
        searchInput.value
            .toLowerCase()
            .trim();


    if (searchValue === "") {

        alert(
            "Please enter a destination."
        );

        return;

    }


    let found = false;


    destinationCards.forEach(card => {

        const name =
            card.dataset.name
                .toLowerCase();


        if (
            name.includes(searchValue)
        ) {

            card.style.display = "block";

            card.style.opacity = "1";

            card.style.transform =
                "scale(1)";

            found = true;

        }

        else {

            card.style.display = "none";

        }

    });


    document
        .getElementById("destinations")
        .scrollIntoView({
            behavior: "smooth"
        });


    if (!found) {

        alert(
            "Sorry, destination not found."
        );

    }

});



/* =================================================
                BOOKING FORM
================================================= */

const bookingForm =
    document.getElementById(
        "bookingForm"
    );


bookingForm.addEventListener(
    "submit",
    function(event) {

        event.preventDefault();


        const name =
            document.getElementById(
                "bookingName"
            ).value;


        const destination =
            document.getElementById(
                "bookingDestination"
            ).value;


        alert(
            `Thank you ${name}! Your trip to ${destination} request has been received.`
        );


        bookingForm.reset();

    }
);



/* =================================================
              QUICK SEARCH DATE
================================================= */

const dateInput =
    document.getElementById(
        "travelDate"
    );


const today =
    new Date()
        .toISOString()
        .split("T")[0];


dateInput.min = today;



/* =================================================
             NAVBAR SHADOW
================================================= */

window.addEventListener(
    "scroll",
    () => {

        const header =
            document.querySelector("header");


        if (window.scrollY > 50) {

            header.style.boxShadow =
                "0 5px 25px rgba(0,0,0,.08)";

        }

        else {

            header.style.boxShadow =
                "none";

        }

    }
);