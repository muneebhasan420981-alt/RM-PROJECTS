 Dentiva

Dentiva is a static, multi-page dental information website. It brings together patient and professional education, dental research, product information, and contact details in one responsive site.

 Pages

- index.html — homepage and site overview
- patient.html — patient dental-health education
- professional.html — education for dental professionals
- research.html — dental research and media
- products.html — product catalogue
- about.html — information about Dentiva
- contact.html — contact information and enquiry page
- sitemap.html — links to the site's pages

 Run locally

No build step or package installation is required. Open index.html in a browser, or serve the project directory over HTTP. For example, if Python is installed:

bash
python -m http.server 8000


Then visit <http://localhost:8000>.

Serving over HTTP is recommended because the product page loads product.json with fetch(). Browser geolocation also generally requires a secure context (HTTPS or localhost) and the visitor's permission.

 Project structure

text
.
├── index.html
├── patient.html
├── professional.html
├── research.html
├── products.html
├── about.html
├── contact.html
├── sitemap.html
├── product.json
├── dentiva.png
└── assets/
    ├── css/    Page styles and responsive styles
    └── js/     Navigation, product, time, and shared scripts


The site is built with HTML, CSS, and vanilla JavaScript. Icons use Font Awesome from a CDN; some page imagery is also loaded from external sources, so those assets require an internet connection.
