const heroSlides = document.querySelectorAll(".hero-slide");
const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

if (!prefersReducedMotion) {
    let activeSlide = 0;

    window.setInterval(() => {
        heroSlides[activeSlide].classList.remove("is-active");
        activeSlide = (activeSlide + 1) % heroSlides.length;
        heroSlides[activeSlide].classList.add("is-active");
    }, 5000);
}