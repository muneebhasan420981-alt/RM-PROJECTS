const styles = document.createElement("style");
styles.textContent = `
    body {
        margin: 0;
        background: #f4f8f6;
        color: #203b3a;
        font-family: "Segoe UI", sans-serif;
    }

    .product-page {
        max-width: 1180px;
        margin: 0 auto;
        padding: 64px 24px;
    }

    .product-heading {
        margin-bottom: 32px;
    }

    .product-eyebrow {
        margin: 0 0 10px;
        color: #0095B6;
        font-size: 12px;
        font-weight: 700;
        letter-spacing: 1.4px;
        text-transform: uppercase;
    }

    .product-heading h1 {
        margin: 0;
        color: #203b3a;
        font-size: clamp(32px, 5vw, 48px);
        line-height: 1.1;
    }

    .product-heading p:last-child {
        max-width: 560px;
        margin: 12px 0 0;
        color: #617572;
        line-height: 1.6;
    }

    .product-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(min(100%, 245px), 1fr));
        gap: 20px;
    }

    .product-filters {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        margin: 0 0 24px;
    }

    .product-filter {
        min-height: 40px;
        padding: 0 18px;
        border: 1px solid #d3e1dc;
        border-radius: 6px;
        background: #fff;
        color: #36514d;
        font: inherit;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        transition: background-color 160ms ease, color 160ms ease, border-color 160ms ease;
    }

    .product-filter:hover,
    .product-filter.is-active {
        border-color: #0095B6;
        background: #0095B6;
        color: #fff;
    }

    .product-filter:focus-visible {
        outline: 3px solid #9ad7cb;
        outline-offset: 2px;
    }

    .product-card {
        overflow: hidden;
        background: #fff;
        border: 1px solid #e1eae6;
        border-radius: 8px;
        box-shadow: 0 8px 24px rgb(33 72 65 / 5%);
        animation: card-arrive 420ms ease both;
    }

    .product-visual {
        display: grid;
        min-height: 148px;
        place-items: center;
        background: linear-gradient(135deg, #d8efea, #eff4df);
    }

    .product-visual img {
        width: 100%;
        height: 180px;
        object-fit: cover;
    }

    .product-placeholder {
        display: grid;
        width: 74px;
        height: 74px;
        place-items: center;
        border: 1px solid rgb(22 132 119 / 25%);
        border-radius: 50%;
        color: #0095B6;
        font-size: 28px;
        font-weight: 700;
    }

    .product-info {
        padding: 18px;
    }

    .product-category {
        margin: 0 0 8px;
        color: #0095B6;
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 1px;
    }

    .product-info h2 {
        margin: 0 0 10px;
        color: #203b3a;
        font-size: 20px;
    }

    .product-description {
        margin: 0;
        color: #617572;
        font-size: 14px;
        line-height: 1.6;
    }

    .product-rating {
        margin-top: 18px;
        padding-top: 14px;
        border-top: 1px solid #e1eae6;
    }

    .product-rating-label {
        margin: 0 0 6px;
        color: #36514d;
        font-size: 12px;
        font-weight: 600;
    }

    .product-rating-stars {
        display: flex;
        gap: 2px;
    }

    .product-rating-star {
        display: grid;
        width: 32px;
        height: 32px;
        place-items: center;
        padding: 0;
        border: 0;
        background: transparent;
        color: #aebbb8;
        cursor: pointer;
        font-size: 16px;
    }

    .product-rating-star:hover,
    .product-rating-star.is-selected {
        color: #d28a13;
    }

    .product-rating-star:focus-visible {
        border-radius: 4px;
        outline: 2px solid #0095B6;
        outline-offset: 1px;
    }

    .product-rating-value {
        min-height: 16px;
        margin: 6px 0 0;
        color: #617572;
        font-size: 12px;
    }

    .product-status {
        margin: 0;
        padding: 20px 0;
        color: #617572;
    }

    @keyframes card-arrive {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }

    @media (prefers-reduced-motion: reduce) {
        .product-card { animation: none; }
    }
`;
document.head.appendChild(styles);

const main = document.createElement("main");
main.className = "product-page";
main.innerHTML = `
    <header class="product-heading">
        <p class="product-eyebrow">Everyday essentials</p>
        <h1>Oral care products</h1>
        <p>Simple essentials for a healthy, confident smile.</p>
    </header>
    <div class="product-filters" role="group" aria-label="Filter products">
        <button class="product-filter is-active" id="ALL" type="button" aria-pressed="true">ALL</button>
        <button class="product-filter" id="home" type="button" aria-pressed="false">home</button>
        <button class="product-filter" id="dental" type="button" aria-pressed="false">Dental</button>
        <button class="product-filter" id="profession" type="button" aria-pressed="false">Professional</button>
    </div>
    <section class="product-grid" aria-label="Dental products" aria-live="polite"></section>
`;
document.body.appendChild(main);

const productGrid = main.querySelector(".product-grid");
const filterButtons = main.querySelectorAll(".product-filter");
let productData = [];

function createProductCard(product) {
	const card = document.createElement("article");
	card.className = "product-card";
	card.dataset.productId = String(product.id);

	const visual = document.createElement("div");
	visual.className = "product-visual";

	if (product.image) {
		const image = document.createElement("img");
		image.src = product.image;
		image.alt = product.name;
		visual.append(image);
	} else {
		const placeholder = document.createElement("span");
		placeholder.className = "product-placeholder";
		placeholder.setAttribute("aria-hidden", "true");
		placeholder.textContent = String(product.id).padStart(2, "0");
		visual.append(placeholder);
	}

	const info = document.createElement("div");
	info.className = "product-info";

	const category = document.createElement("p");
	category.className = "product-category";
	category.textContent = product.category;

	const name = document.createElement("h2");
	name.textContent = product.name;

	const description = document.createElement("p");
	description.className = "product-description";
	description.textContent = product.description;

	const rating = createRatingControl(product);
	info.append(category, name, description, rating);
	card.append(visual, info);
	return card;
}
function getSavedRating(productId) {
    try {
        const rating = Number(localStorage.getItem(`dentiva-product-rating-${productId}`));
        return Number.isInteger(rating) && rating >= 1 && rating <= 5 ? rating : 0;
    } catch {
        return 0;
    }
}

function createRatingControl(product) {
    const rating = document.createElement("div");
    rating.className = "product-rating";

    const label = document.createElement("p");
    label.className = "product-rating-label";
    label.textContent = "Rate this product";

    const stars = document.createElement("div");
    stars.className = "product-rating-stars";
    stars.setAttribute("role", "radiogroup");
    stars.setAttribute("aria-label", `Rate ${product.name}`);

    const savedRating = getSavedRating(product.id);
    for (let value = 1; value <= 5; value += 1) {
        const button = document.createElement("button");
        button.className = "product-rating-star";
        button.type = "button";
        button.setAttribute("role", "radio");
        button.setAttribute("aria-label", `${value} ${value === 1 ? "star" : "stars"}`);
        button.setAttribute("aria-checked", String(value === savedRating));
        button.tabIndex = value === (savedRating || 1) ? 0 : -1;
        button.dataset.rating = String(value);
        button.classList.toggle("is-selected", value <= savedRating);

        const icon = document.createElement("i");
        icon.className = "fa-solid fa-star";
        icon.setAttribute("aria-hidden", "true");
        button.append(icon);
        stars.append(button);
    }

    const valueLabel = document.createElement("p");
    valueLabel.className = "product-rating-value";
    valueLabel.setAttribute("aria-live", "polite");
    valueLabel.textContent = savedRating ? `Your rating: ${savedRating} out of 5` : "Not rated yet";

    rating.append(label, stars, valueLabel);
    return rating;
}

function saveRating(card, value) {
    const productId = card.dataset.productId;
    try {
        localStorage.setItem(`dentiva-product-rating-${productId}`, String(value));
    } catch {
        // Keep the current rating usable even when browser storage is unavailable.
    }

    const stars = card.querySelectorAll(".product-rating-star");
    stars.forEach((star) => {
        const isSelected = Number(star.dataset.rating) <= value;
        star.classList.toggle("is-selected", isSelected);
        star.setAttribute("aria-checked", String(Number(star.dataset.rating) === value));
        star.tabIndex = Number(star.dataset.rating) === value ? 0 : -1;
    });

    card.querySelector(".product-rating-value").textContent = `Your rating: ${value} out of 5`;
}
productGrid.addEventListener("click", (event) => {
	const star = event.target.closest(".product-rating-star");
	if (!star) {
		return;
	}

	const card = star.closest(".product-card");
	saveRating(card, Number(star.dataset.rating));
});

productGrid.addEventListener("keydown", (event) => {
	const star = event.target.closest(".product-rating-star");
	if (!star || !["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"].includes(event.key)) {
		return;
	}

	const stars = [...star.closest(".product-rating-stars").querySelectorAll(".product-rating-star")];
	const currentIndex = stars.indexOf(star);
	const movesForward = event.key === "ArrowRight" || event.key === "ArrowUp";
	const nextIndex = (currentIndex + (movesForward ? 1 : -1) + stars.length) % stars.length;
	event.preventDefault();
	stars[nextIndex].focus();
	stars[nextIndex].click();
});

function showStatus(message) {
	const status = document.createElement("p");
	status.className = "product-status";
	status.textContent = message;
	productGrid.replaceChildren(status);
}

function renderProducts(filter) {
    const normalizedFilter = String(filter).toLowerCase();

    filterButtons.forEach((button) => {
        const isActive = button.id.toLowerCase() === normalizedFilter;
        button.classList.toggle("is-active", isActive);
        button.setAttribute("aria-pressed", String(isActive));
    });

    const filteredProducts = productData.filter((product) => {
        const category = String(product.category || "").toLowerCase();
        if (normalizedFilter === "all") {
            return true;
        }
        if (normalizedFilter === "dental") {
            return category === "dental";
        }
        if (normalizedFilter === "home") {
            return category === "home";
        }
        if (normalizedFilter === "profession") {
            return category === "profession";
        }
        return true;
    });

    if (filteredProducts.length === 0) {
        showStatus("No products found in this category.");
        return;
    }

    productGrid.replaceChildren(...filteredProducts.map(createProductCard));
}

productFilterContainer.addEventListener("click", (event) => {
    const button = event.target.closest(".product-filter");
    if (button) {
        renderProducts(button.id);
    }
});

fetch("./product.json")
    .then((response) => {
        if (!response.ok) {
            throw new Error(`Product data request failed: ${response.status}`);
        }
        return response.json();
    })
    .then((products) => {
        if (!Array.isArray(products)) {
            throw new Error("Product data must be an array.");
        }

        productData = products;
        renderProducts("ALL");
    })
    .catch(() => showStatus("Products could not be loaded. Please try again later."));
