const clockDate = document.querySelector("#status-date");
const clockTime = document.querySelector("#status-time");
const clockYear = document.querySelector("#status-year");

if (clockDate && clockTime && clockYear) {
    const updateClock = () => {
        const now = new Date();
        clockDate.textContent = new Intl.DateTimeFormat(undefined, {
            weekday: "short",
            month: "short",
            day: "numeric"
        }).format(now);
        clockTime.textContent = new Intl.DateTimeFormat(undefined, {
            hour: "2-digit",
            minute: "2-digit",
            second: "2-digit"
        }).format(now);
        clockYear.textContent = String(now.getFullYear());
    };

    updateClock();
    window.setInterval(updateClock, 1000);
}

const locationOutput = document.querySelector("#status-location");

if (locationOutput) {
    if ("geolocation" in navigator) {
        locationOutput.textContent = "Allow location";
        navigator.geolocation.watchPosition(
            ({ coords }) => {
                locationOutput.textContent = `${coords.latitude.toFixed(3)}, ${coords.longitude.toFixed(3)}`;
            },
            () => {
                locationOutput.textContent = "Location unavailable";
            },
            { enableHighAccuracy: false, maximumAge: 60000, timeout: 10000 }
        );
    } else {
        locationOutput.textContent = "Location unavailable";
    }
}

const visitorOutput = document.querySelector("#status-visitors");

if (visitorOutput) {
    const countKey = "dentiva-dummy-visitors";
    const visitKey = "dentiva-visit-counted";

    try {
        let count = Number(localStorage.getItem(countKey)) || 1284;
        if (!sessionStorage.getItem(visitKey)) {
            count += 1;
            localStorage.setItem(countKey, String(count));
            sessionStorage.setItem(visitKey, "true");
        }
        visitorOutput.textContent = count.toLocaleString();
    } catch {
        visitorOutput.textContent = "1,285";
    }
}

const navigation = document.querySelector("nav");
const menuButton = navigation?.querySelector(".mobile-menu-toggle");
const navigationLinks = navigation?.querySelector("#primary-navigation");

if (navigation && menuButton && navigationLinks) {
    const closeMenu = () => {
        menuButton.setAttribute("aria-expanded", "false");
        menuButton.setAttribute("aria-label", "Open navigation menu");
        navigationLinks.classList.remove("is-open");

        const icon = menuButton.querySelector("i");
        icon?.classList.replace("fa-xmark", "fa-bars");
    };

    menuButton.addEventListener("click", () => {
        const isOpen = menuButton.getAttribute("aria-expanded") !== "true";

        menuButton.setAttribute("aria-expanded", String(isOpen));
        menuButton.setAttribute(
            "aria-label",
            isOpen ? "Close navigation menu" : "Open navigation menu"
        );
        navigationLinks.classList.toggle("is-open", isOpen);

        const icon = menuButton.querySelector("i");
        icon?.classList.toggle("fa-bars", !isOpen);
        icon?.classList.toggle("fa-xmark", isOpen);
    });

    navigationLinks.addEventListener("click", (event) => {
        if (event.target instanceof Element && event.target.closest("a")) {
            closeMenu();
        }
    });

    document.addEventListener("click", (event) => {
        if (!navigation.contains(event.target)) {
            closeMenu();
        }
    });

    navigation.addEventListener("keydown", (event) => {
        if (event.key === "Escape" && menuButton.getAttribute("aria-expanded") === "true") {
            closeMenu();
            menuButton.focus();
        }
    });

    window.addEventListener("resize", () => {
        if (window.matchMedia("(min-width: 641px)").matches) {
            closeMenu();
        }
    });
}