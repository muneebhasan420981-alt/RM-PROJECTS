const productsContainer = document.getElementById("products-container");
const searchInput = document.getElementById("search-input");
const categoryFilter = document.getElementById("category-filter");
const sortFilter = document.getElementById("sort-filter");
const productCount = document.getElementById("product-count");
const cartCount = document.getElementById("cart-count");
const productsDataUrl = new URL("../json/product.json", document.currentScript.src);



let products = [];
let cart = JSON.parse(localStorage.getItem("chronoCart")) || [];


function formatPrice(price) {
    return "Rs. " + price.toLocaleString("en-PK");
}


function updateCartCount() {
    const totalItems = cart.reduce((total, item) => total + item.quantity, 0);

    cartCount.textContent = totalItems;
}


function addToCart(productId) {

    const product = products.find(item => item.id === productId);

    if (!product) return;

    const existingItem = cart.find(item => item.id === productId);

    if (existingItem) {
        existingItem.quantity++;
    } else {
        cart.push({
            id: product.id,
            name: product.name,
            price: product.price,
            quantity: 1
        });
    }

    localStorage.setItem("chronoCart", JSON.stringify(cart));

    updateCartCount();

    alert(product.name + " added to cart!");
}


function displayProducts(productList) {

    productsContainer.innerHTML = "";

    productCount.textContent =
        productList.length + " Products Found";


    if (productList.length === 0) {

        productsContainer.innerHTML = `
            <div class="no-products">
                <i class="fa-solid fa-magnifying-glass"></i>
                <h3>No Products Found</h3>
                <p>Try searching another watch.</p>
            </div>
        `;

        return;
    }


    productList.forEach(product => {

        const card = document.createElement("div");

        card.className = "product-card";

        const oldPrice = product.oldPrice
            ? `<del>${formatPrice(product.oldPrice)}</del>`
            : "";

        card.innerHTML = `
            <div class="product-image">

                <img src="${product.image}"
                     alt="${product.name}"
                     loading="lazy">

                <span class="product-badge">
                    ${product.badge}
                </span>

            </div>

            <div class="product-info">

                <span class="product-category">
                    ${product.category}
                </span>

                <h3>${product.name}</h3>

                <p class="product-description">
                    ${product.description}
                </p>

                <div class="product-price">
                    ${formatPrice(product.price)}
                    ${oldPrice}
                </div>

                <button class="add-cart"
                    data-id="${product.id}">
                    <i class="fa-solid fa-cart-shopping"></i>
                    Add to Cart
                </button>

            </div>
        `;

        productsContainer.appendChild(card);

    });



    document.querySelectorAll(".add-cart").forEach(button => {

        button.addEventListener("click", function() {

            const productId = Number(this.dataset.id);

            addToCart(productId);

        });

    });

}


function filterProducts() {

    const searchValue = searchInput.value.toLowerCase();

    const categoryValue = categoryFilter.value;

    const sortValue = sortFilter.value;


    let filteredProducts = products.filter(product => {

        const matchesSearch =
            product.name.toLowerCase().includes(searchValue) ||
            product.category.toLowerCase().includes(searchValue);

        const matchesCategory =
            categoryValue === "All" ||
            product.category === categoryValue;

        return matchesSearch && matchesCategory;

    });


    if (sortValue === "low") {

        filteredProducts.sort((a, b) => a.price - b.price);

    }

    else if (sortValue === "high") {

        filteredProducts.sort((a, b) => b.price - a.price);

    }


    displayProducts(filteredProducts);

}


async function loadProducts() {

    try {

        const response = await fetch(productsDataUrl);

        if (!response.ok) {
            throw new Error("Unable to load product.json");
        }

        products = await response.json();

        filterProducts();

        updateCartCount();

    }

    catch(error) {

        productsContainer.innerHTML = `
            <div class="no-products">
                <h3>Products Could Not Load</h3>
                <p>Please run the website using Live Server.</p>
            </div>
        `;

        console.error(error);

    }

}

searchInput.addEventListener("input", filterProducts);

categoryFilter.addEventListener("change", filterProducts);

sortFilter.addEventListener("change", filterProducts);

const requestedCategory = new URLSearchParams(window.location.search).get("category");

if (requestedCategory && Array.from(categoryFilter.options).some(option => option.value === requestedCategory)) {
    categoryFilter.value = requestedCategory;
}

loadProducts();
