const stores = [
    {
        name: "Alberto Clifton",
        city: "Karachi",
        address: "Dolmen Mall Clifton, Karachi, Pakistan",
        phone: "+92 300 1234567",
        hours: "11:00 AM - 10:00 PM",
        searchAddress: "Karachi Pakistan"
    },

    {
        name: "Alberto Lahore",
        city: "Lahore",
        address: "MM Alam Road, Lahore, Pakistan",
        phone: "+92 300 7654321",
        hours: "11:00 AM - 10:00 PM",
        searchAddress: "Lahore Pakistan"
    },

    {
        name: "Alberto Islamabad",
        city: "Islamabad",
        address: "Centaurus Mall, Islamabad, Pakistan",
        phone: "+92 300 9876543",
        hours: "12:00 PM - 10:00 PM",
        searchAddress: "Islamabad Pakistan"
    }
];


const storeGrid = document.getElementById("storeGrid");
const searchInput = document.getElementById("searchInput");
const searchBtn = document.getElementById("searchBtn");
const storeCount = document.getElementById("storeCount");
const noResults = document.getElementById("noResults");
const locationBtn = document.getElementById("locationBtn");


function displayStores(storeList) {

    storeGrid.innerHTML = "";

    storeCount.textContent =
        `${storeList.length} ${storeList.length === 1 ? "Store" : "Stores"} Available`;

    if (storeList.length === 0) {
        noResults.style.display = "block";
        storeGrid.style.display = "none";
        return;
    }

    noResults.style.display = "none";
    storeGrid.style.display = "grid";

    storeList.forEach((store, index) => {

        const card = document.createElement("article");
        card.className = "store-card";

        card.style.animationDelay = `${index * 0.1}s`;

        card.innerHTML = `
            <div class="store-icon">
                <i class="fa-solid fa-store"></i>
            </div>

            <h3>${store.name}</h3>

            <p class="city">${store.city}</p>

            <div class="store-info">
                <i class="fa-solid fa-location-dot"></i>
                <span>${store.address}</span>
            </div>

            <div class="store-info">
                <i class="fa-solid fa-phone"></i>
                <span>${store.phone}</span>
            </div>

            <div class="store-info">
                <i class="fa-regular fa-clock"></i>
                <span>
                    <strong>Opening Hours</strong><br>
                    ${store.hours}
                </span>
            </div>

            <span class="store-status">
                <i class="fa-solid fa-circle-check"></i>
                Store Available
            </span>

            <a
                href="https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(store.name + " " + store.searchAddress)}"
                target="_blank"
                rel="noopener noreferrer"
                class="directions-btn"
            >
                <i class="fa-solid fa-route"></i>
                Get Directions
            </a>
        `;

        storeGrid.appendChild(card);

    });
}


function searchStores() {

    const searchValue = searchInput.value
        .trim()
        .toLowerCase();

    const filteredStores = stores.filter(store => {

        return (
            store.name.toLowerCase().includes(searchValue) ||
            store.city.toLowerCase().includes(searchValue) ||
            store.address.toLowerCase().includes(searchValue)
        );

    });

    displayStores(filteredStores);
}


searchBtn.addEventListener("click", searchStores);

searchInput.addEventListener("input", searchStores);

searchInput.addEventListener("keydown", function(event) {

    if (event.key === "Enter") {
        searchStores();
    }

});


locationBtn.addEventListener("click", function() {

    if (!navigator.geolocation) {

        alert("Geolocation is not supported by your browser.");
        return;

    }

    locationBtn.innerHTML =
        '<i class="fa-solid fa-spinner fa-spin"></i> Locating...';

    navigator.geolocation.getCurrentPosition(

        function(position) {

            const latitude = position.coords.latitude;
            const longitude = position.coords.longitude;

            const mapURL =
                `https://www.google.com/maps/search/watch+store/@${latitude},${longitude},14z`;

            window.open(mapURL, "_blank", "noopener,noreferrer");

            locationBtn.innerHTML =
                '<i class="fa-solid fa-location-crosshairs"></i> Locate Me';

        },

        function() {

            alert("Unable to access your location. Please allow location permission.");

            locationBtn.innerHTML =
                '<i class="fa-solid fa-location-crosshairs"></i> Locate Me';

        }

    );

});


displayStores(stores);