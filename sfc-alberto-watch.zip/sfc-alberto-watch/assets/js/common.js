(() => {
    const topBar = document.querySelector(".top-bar");
    if (topBar) {
        const visitorCounter = document.createElement("span");
        visitorCounter.className = "visitor-counter";
        visitorCounter.setAttribute("aria-live", "polite");
        visitorCounter.textContent = "Visits from this browser: loading...";
        topBar.append(visitorCounter);

        try {
            const countKey = "albertoLocalVisitorCount";
            const sessionKey = "albertoVisitorCountedThisTab";
            const storedCount = Number(localStorage.getItem(countKey) || 0);
            let visitCount = Number.isSafeInteger(storedCount) && storedCount >= 0
                ? storedCount
                : 0;

            if (sessionStorage.getItem(sessionKey) !== "true") {
                visitCount += 1;
                localStorage.setItem(countKey, String(visitCount));
                sessionStorage.setItem(sessionKey, "true");
            }

            visitorCounter.textContent =
                `Visits from this browser: ${visitCount.toLocaleString()}`;
        } catch (error) {
            console.error("Could not access storage for the local visitor counter.", error);
            visitorCounter.textContent = "Visitor counter unavailable";
        }
    }

    const ticker = document.createElement("aside");
    ticker.className = "live-ticker";
    ticker.setAttribute("aria-label", "Live local date, time, and location");
    ticker.innerHTML = `
        <div class="live-ticker-track" aria-hidden="true">
            <div class="live-ticker-copy">
                <span class="live-ticker-time"></span>
                <span class="live-ticker-location">Location: waiting for permission</span>
            </div>
            <div class="live-ticker-copy">
                <span class="live-ticker-time"></span>
                <span class="live-ticker-location">Location: waiting for permission</span>
            </div>
        </div>`;
    document.body.append(ticker);

    const timeLabels = ticker.querySelectorAll(".live-ticker-time");
    const locationLabels = ticker.querySelectorAll(".live-ticker-location");
    const timeFormatter = new Intl.DateTimeFormat(undefined, {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        timeZoneName: "short"
    });

    const updateTime = () => {
        const currentTime = timeFormatter.format(new Date());
        timeLabels.forEach((label) => {
            label.textContent = currentTime;
        });
    };

    updateTime();
    window.setInterval(updateTime, 1000);

    const updateLocation = (message) => {
        locationLabels.forEach((label) => {
            label.textContent = message;
        });
    };

    if (!navigator.geolocation) {
        updateLocation("Location: geolocation is not supported by this browser");
        return;
    }

    navigator.geolocation.watchPosition(
        ({ coords }) => {
            updateLocation(
                `Location: ${coords.latitude.toFixed(4)}, ${coords.longitude.toFixed(4)}`
            );
        },
        (error) => {
            const messages = {
                1: "Location: permission denied",
                2: "Location: unavailable",
                3: "Location: request timed out"
            };
            updateLocation(messages[error.code] || "Location: unavailable");
        },
        { enableHighAccuracy: false, maximumAge: 60000, timeout: 10000 }
    );
})();
