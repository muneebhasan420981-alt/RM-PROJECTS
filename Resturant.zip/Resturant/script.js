/* =================================================
                  MOBILE MENU
================================================= */

const menuBtn =
    document.getElementById("menuBtn");

const navbar =
    document.getElementById("navbar");


menuBtn.addEventListener("click", () => {

    navbar.classList.toggle("active");

    const icon =
        menuBtn.querySelector("i");

    icon.classList.toggle("fa-bars");

    icon.classList.toggle("fa-xmark");

});


document.querySelectorAll("#navbar a")
.forEach(link => {

    link.addEventListener("click", () => {

        navbar.classList.remove("active");

        const icon =
            menuBtn.querySelector("i");

        icon.classList.add("fa-bars");

        icon.classList.remove("fa-xmark");

    });

});



/* =================================================
                    THEME TOGGLE
================================================= */

const themeBtn =
    document.getElementById("themeBtn");


themeBtn.addEventListener("click", () => {

    document.body.classList.toggle("light");

    const icon =
        themeBtn.querySelector("i");

    icon.classList.toggle("fa-moon");

    icon.classList.toggle("fa-sun");

});



/* =================================================
                    FOOD SLIDER
================================================= */

const slides =
    document.querySelectorAll(".slide");

const dots =
    document.querySelectorAll(".slider-dots span");

let currentSlide = 0;


function showSlide(index) {

    slides.forEach(slide => {

        slide.classList.remove("active");

    });


    dots.forEach(dot => {

        dot.classList.remove("active");

    });


    slides[index].classList.add("active");

    dots[index].classList.add("active");

}


document
    .getElementById("nextSlide")
    .addEventListener("click", () => {

        currentSlide++;

        if (
            currentSlide >=
            slides.length
        ) {

            currentSlide = 0;

        }

        showSlide(currentSlide);

    });


document
    .getElementById("prevSlide")
    .addEventListener("click", () => {

        currentSlide--;

        if (currentSlide < 0) {

            currentSlide =
                slides.length - 1;

        }

        showSlide(currentSlide);

    });


dots.forEach((dot, index) => {

    dot.addEventListener("click", () => {

        currentSlide = index;

        showSlide(currentSlide);

    });

});


/* Automatic slider */

setInterval(() => {

    currentSlide++;

    if (
        currentSlide >=
        slides.length
    ) {

        currentSlide = 0;

    }

    showSlide(currentSlide);

}, 5000);



/* =================================================
                  MENU FILTER
================================================= */

const filters =
    document.querySelectorAll(".filter");

const foodCards =
    document.querySelectorAll(".food-card");


filters.forEach(filter => {

    filter.addEventListener("click", () => {

        filters.forEach(btn => {

            btn.classList.remove("active");

        });


        filter.classList.add("active");


        const category =
            filter.dataset.category;


        foodCards.forEach(card => {

            if (
                category === "all" ||
                card.dataset.category === category
            ) {

                card.classList.remove("hidden");

            }

            else {

                card.classList.add("hidden");

            }

        });

    });

});



/* =================================================
                  SHOPPING CART
================================================= */

let cart = [];


const cartCount =
    document.getElementById("cartCount");

const cartModal =
    document.getElementById("cartModal");

const cartItems =
    document.getElementById("cartItems");

const cartTotal =
    document.getElementById("cartTotal");


document
    .querySelectorAll(".order-btn")
    .forEach(button => {

        button.addEventListener("click", () => {

            const name =
                button.dataset.name;

            const price =
                Number(button.dataset.price);


            cart.push({
                name: name,
                price: price
            });


            updateCart();


            button.innerHTML = `

                <i class="fa-solid fa-check"></i>

                Added

            `;


            setTimeout(() => {

                button.innerHTML = `

                    Add to Order

                    <i class="fa-solid fa-plus"></i>

                `;

            }, 1200);

        });

    });



function updateCart() {

    cartCount.textContent =
        cart.length;


    cartItems.innerHTML = "";


    if (cart.length === 0) {

        cartItems.innerHTML = `

            <p class="empty-cart">
                Your order is empty.
            </p>

        `;

    }


    let total = 0;


    cart.forEach((item, index) => {

        total += item.price;


        const div =
            document.createElement("div");


        div.className =
            "cart-item";


        div.innerHTML = `

            <div>

                <strong>
                    ${item.name}
                </strong>

                <span>
                    $${item.price}
                </span>

            </div>

            <button
                class="remove-item"
                data-index="${index}">

                <i class="fa-solid fa-trash"></i>

            </button>

        `;


        cartItems.appendChild(div);

    });


    cartTotal.textContent =
        `$${total}`;


    document
        .querySelectorAll(".remove-item")
        .forEach(button => {

            button.addEventListener(
                "click",
                () => {

                    const index =
                        Number(
                            button.dataset.index
                        );

                    cart.splice(index, 1);

                    updateCart();

                }
            );

        });

}



document
    .getElementById("cartBtn")
    .addEventListener("click", () => {

        cartModal.classList.add("active");

    });


document
    .getElementById("closeCart")
    .addEventListener("click", () => {

        cartModal.classList.remove("active");

    });


cartModal.addEventListener("click", event => {

    if (
        event.target === cartModal
    ) {

        cartModal.classList.remove(
            "active"
        );

    }

});



/* =================================================
                 CHECKOUT
================================================= */

document
    .getElementById("checkoutBtn")
    .addEventListener("click", () => {

        if (cart.length === 0) {

            alert(
                "Your order is empty. Please add a dish first."
            );

            return;

        }


        alert(
            "Thank you! Your order has been received."
        );


        cart = [];

        updateCart();

        cartModal.classList.remove(
            "active"
        );

    });



/* =================================================
                RESERVATION
================================================= */

const reservationForm =
    document.getElementById(
        "reservationForm"
    );


reservationForm.addEventListener(
    "submit",
    event => {

        event.preventDefault();


        const name =
            document.getElementById(
                "reserveName"
            ).value;


        const date =
            document.getElementById(
                "reserveDate"
            ).value;


        alert(
            `Thank you ${name}! Your table request for ${date} has been received.`
        );


        reservationForm.reset();

    }
);



/* =================================================
                   REVIEW SLIDER
================================================= */

const reviews =
    document.querySelectorAll(".review");


let reviewIndex = 0;


function showReview(index) {

    reviews.forEach(review => {

        review.classList.remove(
            "active"
        );

    });


    reviews[index]
        .classList.add("active");

}


document
    .getElementById("reviewNext")
    .addEventListener("click", () => {

        reviewIndex++;


        if (
            reviewIndex >=
            reviews.length
        ) {

            reviewIndex = 0;

        }


        showReview(reviewIndex);

    });


document
    .getElementById("reviewPrev")
    .addEventListener("click", () => {

        reviewIndex--;


        if (reviewIndex < 0) {

            reviewIndex =
                reviews.length - 1;

        }


        showReview(reviewIndex);

    });



/* Automatic reviews */

setInterval(() => {

    reviewIndex++;


    if (
        reviewIndex >=
        reviews.length
    ) {

        reviewIndex = 0;

    }


    showReview(reviewIndex);

}, 6000);



/* =================================================
                  NEWSLETTER
================================================= */

const newsletter =
    document.getElementById(
        "newsletter"
    );


newsletter.addEventListener(
    "submit",
    event => {

        event.preventDefault();


        alert(
            "Thanks for subscribing to Golden Plate!"
        );


        newsletter.reset();

    }
);



/* =================================================
                 SCROLL EFFECT
================================================= */

const animatedElements =
    document.querySelectorAll(
        ".food-card, .about-image, .about-content, .reservation, .review"
    );


const observer =
    new IntersectionObserver(
        entries => {

            entries.forEach(entry => {

                if (
                    entry.isIntersecting
                ) {

                    entry.target.style.opacity =
                        "1";

                    entry.target.style.transform =
                        "translateY(0)";

                }

            });

        },
        {
            threshold: .12
        }
    );


animatedElements.forEach(element => {

    element.style.opacity = "0";

    element.style.transform =
        "translateY(30px)";

    element.style.transition =
        "opacity .7s ease, transform .7s ease";

    observer.observe(element);

});



/* =================================================
                 SET MIN DATE
================================================= */

const dateInput =
    document.getElementById(
        "reserveDate"
    );


const today =
    new Date()
        .toISOString()
        .split("T")[0];


dateInput.min = today;